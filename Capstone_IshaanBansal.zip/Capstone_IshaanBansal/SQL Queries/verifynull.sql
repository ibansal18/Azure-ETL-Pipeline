

SELECT * 
FROM [cap].[Customers]
WHERE customer_id IS NULL 
   OR first_name IS NULL 
   OR last_name IS NULL 
   OR email IS NULL 
   OR signup_date IS NULL 
   OR address IS NULL;

   SELECT * 
FROM cap.Products
WHERE product_id IS NULL 
   OR product_name IS NULL 
   OR category IS NULL 
   OR price IS NULL 
   OR stock_quantity IS NULL;
SELECT * 
FROM cap.Reviews
WHERE review_id IS NULL 
   OR customer_id IS NULL 
   OR product_id IS NULL 
   OR review_text IS NULL 
   OR rating IS NULL 
   OR review_date IS NULL;
SELECT * 
FROM cap.Inventory
WHERE product_id IS NULL 
   OR current_stock IS NULL 
   OR reorder_level IS NULL;
SELECT * 
FROM cap.Transactions
WHERE transaction_id IS NULL 
   OR customer_id IS NULL 
   OR transaction_date IS NULL 
   OR transaction_amount IS NULL 
   OR product_id IS NULL 
   OR quantity IS NULL 
   OR payment_type IS NULL;

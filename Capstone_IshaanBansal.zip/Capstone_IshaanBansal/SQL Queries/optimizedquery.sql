SELECT transaction_id, customer_id, transaction_amount, transaction_date
FROM cap.Transactions
WHERE transaction_date <= '2024-10-05';
go

SELECT transaction_id, customer_id, transaction_amount, transaction_date
FROM cap.Transactions
go

SELECT transaction_id, customer_id, transaction_amount, transaction_date
FROM cap.Transactions
WHERE transaction_date > '2024-10-05';
go

SELECT customer_id, SUM(transaction_amount) AS total_spent
FROM cap.Transactions
WHERE transaction_date <= '2024-10-05'
GROUP BY customer_id;
go

SELECT customer_id, SUM(transaction_amount) AS total_spent
FROM cap.Transactions
WHERE transaction_date <= '2024-10-05'
GROUP BY customer_id;
go

SELECT payment_type, COUNT(transaction_id) AS transaction_count
FROM cap.Transactions
WHERE transaction_date > '2024-10-05'
GROUP BY payment_type;
go

SELECT transaction_id, transaction_date, transaction_amount
FROM cap.Transactions
WHERE transaction_date BETWEEN '2024-10-01' AND '2024-10-05';
go


SET SHOWPLAN_ALL ON;
SELECT ProductID, ProductName, Price
FROM dbo.ProductData
WHERE ProductCategory = 'Fashion';
SET SHOWPLAN_ALL OFF;

SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT ProductID, ProductName, Price
FROM dbo.ProductData
WHERE ProductCategory = 'Electronics';
SET STATISTICS TIME OFF;
SET STATISTICS IO OFF;
 
SET SHOWPLAN_ALL ON;
SELECT ProductID, ProductName, Price
FROM dbo.ProductData
WHERE ProductCategory = 'Fashion';
SET SHOWPLAN_ALL OFF;
 
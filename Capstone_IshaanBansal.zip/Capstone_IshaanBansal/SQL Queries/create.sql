create schema cap
go


CREATE TABLE cap.Customers (
    customer_id INT PRIMARY KEY,
    first_name NVARCHAR(50),
    last_name NVARCHAR(50),
    email NVARCHAR(100),
    signup_date DATE,
    address NVARCHAR(255)
)
go
CREATE TABLE cap.Products (
    product_id INT PRIMARY KEY,
    product_name NVARCHAR(100),
    category NVARCHAR(50),
    price DECIMAL(10, 2),
    stock_quantity INT
)
go

CREATE TABLE cap.Inventory (
    product_id INT PRIMARY KEY,
    current_stock INT,
    reorder_level INT,
    FOREIGN KEY (product_id) REFERENCES cap.Products(product_id)
)
go
CREATE TABLE cap.Transactions (
    transaction_id INT PRIMARY KEY,
    customer_id INT,
    transaction_date DATETIME,
    transaction_amount DECIMAL(10, 2),
    product_id INT,
    quantity INT,
    payment_type NVARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES cap.Customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES cap.Products(product_id)
)
go

CREATE TABLE cap.Reviews (
    review_id INT PRIMARY KEY,
    customer_id INT,
    product_id INT,
    review_text NVARCHAR(MAX),
    rating INT,
    review_date DATE,
    FOREIGN KEY (customer_id) REFERENCES cap.Customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES cap.Products(product_id)
)
go

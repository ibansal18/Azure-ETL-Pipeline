CREATE PARTITION FUNCTION PF_TransactionDatecap (DATE)
AS RANGE LEFT FOR VALUES ('2024-10-05');
go
CREATE PARTITION SCHEME PS_TransactionDatecap
AS PARTITION PF_TransactionDatecap
ALL TO ([PRIMARY]);
go
CREATE CLUSTERED INDEX idx_Transactions_Datecap
ON cap.Transactions (transaction_date)
ON PS_TransactionDatecap (transaction_date);
go

--DROP INDEX idx_Transactions_Date ON cap.Transactions;
--DROP PARTITION SCHEME PS_TransactionDatea;
--DROP PARTITION FUNCTION PF_TransactionDateb;

CREATE PARTITION FUNCTION PF_ProductCategoryi (nvarchar(50))
AS RANGE LEFT FOR VALUES ('Electronics', 'Accessories');


-- Create Partition Scheme
CREATE PARTITION SCHEME PS_ProductCategoryi
AS PARTITION PF_ProductCategoryi TO (PRIMARY, PRIMARY);


CREATE NONCLUSTERED INDEX IX_ProductCategory_Price
ON dbo.ProductData (ProductCategory, Price)
ON PS_ProductCategory (ProductCategory);